<?php
$conn = mysqli_connect('localhost', 'root', '','mypayroll');

if($conn-> connect_error)
{
	echo "connection failed";
}
	
	$sqll="select max(Emp_ID) from employee_tl";
	$result=mysqli_query($conn,$sqll);
	$row=mysqli_fetch_row($result);
	$maxID=$row[0];
	echo $maxID;

	$Utility_Allowance='0';
	$Gross_Salary='0';
	$Basic_Sal='0';
	$Gross_Deduction='0';
	$Absent_Days='0';

	
	while($maxID != 0)
	{
		$sql8 = "select Designation_ID from employee_tl where Emp_ID = $maxID ";
		$result14 = mysqli_query($conn,$sql8);
		$result15 = mysqli_fetch_row($result14);
		$Designation_ID = $result15[0];	
		
		//salary deducted due to absents is step 1.
		$Basic_Sal0 = "select Basic_Sal from designation_tl where Designation_ID='$Designation_ID'";
		$Basic_Sal1 = mysqli_query($conn,$Basic_Sal0);
		$Basic_Sal2 = mysqli_fetch_row($Basic_Sal1);
		$Basic_Sal = $Basic_Sal2[0];
		echo $Basic_Sal;
		
		$month0 = "select month from attendance_tl where Emp_ID='$maxID'";
		$month1 = mysqli_query($conn,$month0);
		$month2 = mysqli_fetch_row($month1);
		$month = $month2[0];
		echo $month;
		
		$days0 = "select days from month_tl where month ='$month'";
		$days1 = mysqli_query($conn,$days0);
		$days2 = mysqli_fetch_row($days1);
		$days = $days2[0];
		echo $days;
		
		$per_day_sal = $Basic_Sal / $days;
		echo $per_day_sal;
		
		$sql = "select Absent_Days from attendance_tl where Emp_ID = $maxID";
		$result = mysqli_query($conn,$sql);
		$result1 = mysqli_fetch_row($result);
		$Absent_days = $result1[0];
		echo $Absent_days;
		
		$absent_days_ded = $Absent_days * $per_day_sal;
		echo " ";
		echo $absent_days_ded;
	
		$sql1 = "select Sick_Leave from leave_tl where Emp_ID = $maxID";
		$result2 = mysqli_query($conn,$sql1);
		$result3 = mysqli_fetch_row($result2);
		$Sick_Leave = $result3[0];
		if($Sick_Leave>5)
		{
			$Sick_Leave = $Sick_Leave - 5;
			$Sick_Leave = $Sick_Leave * $per_day_sal;
			echo $Sick_Leave;
		}
		
		
		
		$sql2 = "select Casual_Leave from leave_tl where Emp_ID = $maxID";
		$result4 = mysqli_query($conn,$sql2);
		$result5 = mysqli_fetch_row($result4);
		$Casual_Leave = $result5[0];
	
		if($Casual_Leave>3)
		{
			$Casual_Leave = $Casual_Leave - 3;
			$Casual_Leave = $Casual_Leave * $per_day_sal;
		}
		
		
		$sql5 = "select Tax from emp_ded_tl where Emp_ID = $maxID";
		$result8 = mysqli_query($conn,$sql5);
		$result9 = mysqli_fetch_row($result8);
		$Tax = $result9[0];	
echo $Tax;		
		
		$sql6 = "select PF from emp_ded_tl where Emp_ID = $maxID";
		$result10 = mysqli_query($conn,$sql6);
		$result11 = mysqli_fetch_row($result10);
		$PF = $result11[0];		
echo $PF;
		
		$Total_Ded=$absent_days_ded + $Sick_Leave + $Casual_Leave + $Tax + $PF;
		echo " ";
		echo $Total_Ded;

			

		$sql9 = "select Medical_Allowance from emp_allow_tl where Designation_ID = '$Designation_ID' ";
		$result16 = mysqli_query($conn,$sql9);
		$result17 = mysqli_fetch_row($result16);
		$Medical_Allowance = $result17[0];	
		
		$sql10 = "select Utility_Allowance from emp_allow_tl where Designation_ID = '$Designation_ID' ";
		$result18 = mysqli_query($conn,$sql10);
		$result19 = mysqli_fetch_row($result18);
		$Uility_Allowance = $result19[0];	
		
		$sql11 = "select House_Rent from emp_allow_tl where Designation_ID = '$Designation_ID' ";
		$result20 = mysqli_query($conn,$sql11);
		$result21 = mysqli_fetch_row($result20);
		$House_Rent = $result21[0];	
		
		$Gross_Sal = ($Basic_Sal * (2/3)) + $Medical_Allowance+$House_Rent+$Utility_Allowance;
		echo " ";
		echo $Gross_Sal;
		
		$Net_Sal=$Gross_Sal-$Total_Ded;


		$Department_ID0 = "select Dept_ID from employee_tl where Emp_ID ='$maxID'";
		$Department_ID1 = mysqli_query($conn,$Department_ID0);
		$Department_ID2 = mysqli_fetch_row($Department_ID1);
		$Department_ID = $Department_ID2[0];	
		

		
		$Department_Name0 = "select Dept_Name from department_tl where Dept_ID ='$Department_ID'";
		$Department_Name1 = mysqli_query($conn,$Department_Name0);
		$Department_Name2 = mysqli_fetch_row($Department_Name1);
		$Department_Name = $Department_Name2[0];	
		
	

		$Designation_Name0 = "select Designation_Name from designation_tl where Designation_ID ='$Designation_ID'";
		$Designation_Name1 = mysqli_query($conn,$Designation_Name0);
		$Designation_Name2 = mysqli_fetch_row($Designation_Name1);
		$Designation_Name = $Designation_Name2[0];	
		

		
		$query1 = "Update payslip set Department='$Department_Name', Designation='$Designation_Name', Medical_Allow='$Medical_Allowance', House_Rent='$House_Rent',
					Utility_Allowance='$Uility_Allowance', Provident_Fund='$PF', Tax = '$Tax', Basic_Salary='$Basic_Sal', Gross_Salary='$Gross_Sal',
					Total_Ded='$Total_Ded', Net_Salary='$Net_Sal' where Emp_ID='$maxID'";
					
		if(mysqli_query($conn,$query1))
		{
			echo "updated";
		}
		else
		{
			echo "no";
	}
		
		$maxID= $maxID - 1;
		
		
}
	header("location:payslipdisplay.php");
	
?>
