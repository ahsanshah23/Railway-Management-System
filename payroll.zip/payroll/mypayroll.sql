-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2018 at 09:57 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mypayroll`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance_tl`
--

CREATE TABLE `attendance_tl` (
  `Emp_ID` int(11) NOT NULL,
  `Month` int(11) NOT NULL,
  `Year` int(11) NOT NULL,
  `Absent_Days` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance_tl`
--

INSERT INTO `attendance_tl` (`Emp_ID`, `Month`, `Year`, `Absent_Days`) VALUES
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2);

-- --------------------------------------------------------

--
-- Table structure for table `department_tl`
--

CREATE TABLE `department_tl` (
  `Dept_ID` int(11) NOT NULL,
  `Dept_Name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department_tl`
--

INSERT INTO `department_tl` (`Dept_ID`, `Dept_Name`) VALUES
(1, 'accounting'),
(2, 'finance'),
(3, 'sales'),
(4, 'HR'),
(5, 'marketing'),
(6, 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `designation_tl`
--

CREATE TABLE `designation_tl` (
  `Designation_ID` int(11) NOT NULL,
  `Designation_Name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designation_tl`
--

INSERT INTO `designation_tl` (`Designation_ID`, `Designation_Name`) VALUES
(1, 'Junior _Officer'),
(2, 'Senior_Officer'),
(3, 'Junior_Manager'),
(4, 'Senior_Manager'),
(5, 'Department_Head'),
(6, 'General_Manager'),
(7, 'CEO');

-- --------------------------------------------------------

--
-- Table structure for table `employee_tl`
--

CREATE TABLE `employee_tl` (
  `Emp_ID` int(20) NOT NULL,
  `Emp_Name` varchar(20) NOT NULL,
  `Emp_Father_Name` varchar(20) NOT NULL,
  `Emp_DOB` date NOT NULL,
  `Emp_Age` int(20) NOT NULL,
  `Dept_ID` int(20) NOT NULL,
  `Designation_ID` int(20) NOT NULL,
  `Emp_Date` date NOT NULL,
  `Emp_CNIC` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_tl`
--

INSERT INTO `employee_tl` (`Emp_ID`, `Emp_Name`, `Emp_Father_Name`, `Emp_DOB`, `Emp_Age`, `Dept_ID`, `Designation_ID`, `Emp_Date`, `Emp_CNIC`) VALUES
(1, 'd', 'd', '2018-11-01', 3, 5, 5, '2018-11-07', 6),
(2, 'gjjh', 'fghjg', '2018-11-09', 6, 2, 5, '2018-11-12', 5),
(3, 'ahsan', 'aa', '1212-12-12', 12, 1, 0, '1212-12-12', 12),
(4, 'a', 'a', '1121-02-12', 12, 1, 0, '1212-12-12', 12);

-- --------------------------------------------------------

--
-- Table structure for table `emp_allow_tl`
--

CREATE TABLE `emp_allow_tl` (
  `Designation_ID` int(11) NOT NULL,
  `Medical_Allowance` int(11) NOT NULL,
  `House_Rent` int(11) NOT NULL,
  `Utility_Allowance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_allow_tl`
--

INSERT INTO `emp_allow_tl` (`Designation_ID`, `Medical_Allowance`, `House_Rent`, `Utility_Allowance`) VALUES
(1, 500, 5000, 2000),
(2, 500, 5000, 2000),
(3, 700, 5000, 2000),
(4, 900, 5000, 2000),
(5, 1100, 5000, 2000),
(6, 1300, 5000, 2000),
(7, 1500, 5000, 2000);

-- --------------------------------------------------------

--
-- Table structure for table `emp_ded_tl`
--

CREATE TABLE `emp_ded_tl` (
  `Emp_ID` int(20) NOT NULL,
  `Loan` int(50) NOT NULL,
  `PF` int(50) NOT NULL,
  `Tax` decimal(50,0) NOT NULL,
  `Total_Ded` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_ded_tl`
--

INSERT INTO `emp_ded_tl` (`Emp_ID`, `Loan`, `PF`, `Tax`, `Total_Ded`) VALUES
(1, 5000, 400, '4000', 0),
(2, 5000, 400, '4000', 0),
(3, 4000, 400, '5000', 0),
(4, 3000, 400, '6000', 0);

-- --------------------------------------------------------

--
-- Table structure for table `emp_sal_tl`
--

CREATE TABLE `emp_sal_tl` (
  `Emp_ID` int(20) NOT NULL,
  `Designation_ID` int(11) NOT NULL,
  `Basic_Salary` int(100) NOT NULL,
  `Gross_Sal` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_sal_tl`
--

INSERT INTO `emp_sal_tl` (`Emp_ID`, `Designation_ID`, `Basic_Salary`, `Gross_Sal`) VALUES
(0, 0, 0, 750),
(0, 0, 0, 750),
(0, 0, 0, 750),
(0, 0, 0, 750),
(0, 0, 0, 750),
(0, 0, 0, 750),
(0, 0, 0, 750),
(0, 0, 0, 750),
(0, 0, 0, 750),
(0, 0, 0, 0),
(0, 0, 0, 0),
(0, 0, 0, 0),
(0, 0, 0, 16250),
(0, 0, 0, 16250),
(0, 0, 0, 16250),
(0, 0, 0, 15500),
(0, 0, 0, 16250),
(0, 0, 0, 16250),
(0, 0, 0, 16250),
(0, 0, 0, 16250),
(0, 0, 0, 16250),
(0, 0, 0, 16250),
(0, 0, 0, 16250),
(0, 0, 0, 16250),
(0, 0, 0, 19000),
(0, 0, 0, 19000),
(0, 0, 0, 11650),
(0, 0, 0, 12400),
(0, 0, 0, 19000),
(0, 0, 0, 20000),
(0, 0, 0, 11650),
(0, 0, 0, 12400),
(0, 0, 0, 19000),
(0, 0, 0, 20000),
(0, 0, 0, 11650),
(0, 0, 0, 12400),
(0, 0, 0, 19000),
(0, 0, 0, 20000),
(0, 0, 0, 11650),
(0, 0, 0, 12400),
(0, 0, 0, 19000),
(0, 0, 0, 20000),
(0, 0, 0, 11650),
(0, 0, 0, 12400),
(0, 0, 0, 19000),
(0, 0, 0, 20000),
(0, 0, 0, 11650),
(0, 0, 0, 12400),
(0, 0, 0, 19000),
(0, 0, 0, 20000);

-- --------------------------------------------------------

--
-- Table structure for table `leave_tl`
--

CREATE TABLE `leave_tl` (
  `Emp_ID` int(11) NOT NULL,
  `Sick_Leave` int(11) NOT NULL,
  `Annual_Leave` int(11) NOT NULL,
  `Casual_Leave` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leave_tl`
--

INSERT INTO `leave_tl` (`Emp_ID`, `Sick_Leave`, `Annual_Leave`, `Casual_Leave`) VALUES
(3, 4, 0, 6),
(4, 4, 0, 6),
(1, 4, 2, 0),
(2, 6, 8, 5);

-- --------------------------------------------------------

--
-- Table structure for table `month_tl`
--

CREATE TABLE `month_tl` (
  `Month` int(11) NOT NULL,
  `Days` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sal_reg`
--

CREATE TABLE `sal_reg` (
  `Emp_ID` int(20) NOT NULL,
  `Month` int(20) NOT NULL,
  `Year` int(20) NOT NULL,
  `Gross_Sal` int(100) NOT NULL,
  `Gross_Ded` int(50) NOT NULL,
  `Net_Sal` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sal_reg`
--

INSERT INTO `sal_reg` (`Emp_ID`, `Month`, `Year`, `Gross_Sal`, `Gross_Ded`, `Net_Sal`) VALUES
(4, 0, 0, 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department_tl`
--
ALTER TABLE `department_tl`
  ADD PRIMARY KEY (`Dept_ID`);

--
-- Indexes for table `designation_tl`
--
ALTER TABLE `designation_tl`
  ADD PRIMARY KEY (`Designation_ID`);

--
-- Indexes for table `employee_tl`
--
ALTER TABLE `employee_tl`
  ADD PRIMARY KEY (`Emp_ID`);

--
-- Indexes for table `sal_reg`
--
ALTER TABLE `sal_reg`
  ADD UNIQUE KEY `Emp_ID` (`Emp_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `department_tl`
--
ALTER TABLE `department_tl`
  MODIFY `Dept_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `designation_tl`
--
ALTER TABLE `designation_tl`
  MODIFY `Designation_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `employee_tl`
--
ALTER TABLE `employee_tl`
  MODIFY `Emp_ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
