<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {background-color:#F8F8F9;}

#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

.button {
    background-color: #998AD4;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
	border-radius: 4px;
    margin: 4px 2px;
    cursor: pointer;
}
#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #998AD4;
    color: white;
}
#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}
#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}
</style>
    
    <script type="text/javascript">
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <fieldset>
						<input onclick="window.location.href = 'admin.html'" class="button" type="button" style="float: right;" value="Back" />
						<legend></legend>
						<h2>Pay Slip Details  </h2>
						<hr />
                    <?php
                    $conn = mysqli_connect('localhost', 'root', '','mypayroll');

                    if($conn-> connect_error)
					{
	                  echo "connection failed";
                    }

                    
                    // Attempt select query execution
					
                    $sql = "SELECT * FROM payslip";
                    if($result = mysqli_query($conn, $sql)){
                        if(mysqli_num_rows($result) > 0)
						{ 
                            echo "<table id='customers' class='table table-bordered table-striped'>";
                                echo "<thead>";
                                    echo "<tr>";
                                        echo "<th>Emp ID</th>";
                                        echo "<th>Department</th>";
                                        echo "<th>Designation</th>";
                                        echo "<th>Medical Allowance</th>";
										echo "<th>House Rent</th>";
										echo "<th>Utility Allowance</th>";
										echo "<th>Provident Fund</th>";
                                        echo "<th>Tax</th>";
                                        echo "<th>Basic Salary</th>";
                                        echo "<th>Gross Salary</th>";
										echo "<th>Total Ded</th>";
										echo "<th>Net Salary</th>";
                                    echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";
                                while($row = mysqli_fetch_array($result)){
                                    echo "<tr>";
                                        echo "<td>" . $row['Emp_ID'] . "</td>";
                                        echo "<td>" . $row['Department'] . "</td>";
                                        echo "<td>" . $row['Designation'] . "</td>";
                                        echo "<td>" . $row['Medical_Allow'] . "</td>";
										echo "<td>" . $row['House_Rent'] . "</td>";
										echo "<td>" . $row['Utility_Allowance'] . "</td>";
										echo "<td>" . $row['Provident_Fund'] . "</td>";
                                        echo "<td>" . $row['Tax'] . "</td>";
                                        echo "<td>" . $row['Basic_Salary'] . "</td>";
                                        echo "<td>" . $row['Gross_Salary'] . "</td>";
										echo "<td>" . $row['Total_Ded'] . "</td>";
										echo "<td>" . $row['Net_Salary'] . "</td>";
										 echo "<td>";
                                        echo "<a href='generatepayslip.php?id=". $row['Emp_ID'] ."'>Generate</a>";
                                       
                                        echo "</td>";
                                        
                                    echo "</tr>";
                                }
                                echo "</tbody>";                            
                            echo "</table>";
                            // Free result set
                            mysqli_free_result($result);
                        } else{
                            echo "<p class='lead'><em>No records were found.</em></p>";
                        }
                    } else{
                        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
                    }
 0
                    // Close connection
                    //$conn->close();
                    ?>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>