<?php
if(isset($_POST['done']))
{	
	
	require 'PHPExcel/Classes/PHPExcel.php';
	$conn = mysqli_connect('localhost', 'root', '','mypayroll');
	include ("PHPExcel\IOFactory.php");
	//$html = "<table border='1'>";
	$objPHPExcel= PHPExcel_IOFactory::load('Attendancesheet.xls');
	foreach ($objPHPExcel->getWorksheetIterator() as $worksheet)
	{
		$highestRow = $worksheet->getHighestRow();
		for($row=2; $row<=$highestRow; $row++)
		{
//			$html.="<tr>";
			$Emp_ID =  mysqli_real_escape_string($conn,$worksheet->getCellByColumnAndRow(0,$row)->getValue());
			$Month =  mysqli_real_escape_string($conn,$worksheet->getCellByColumnAndRow(1,$row)->getValue());
			$Year = mysqli_real_escape_string($conn,$worksheet->getCellByColumnAndRow(2,$row)->getValue());
			$Absent_Days = mysqli_real_escape_string($conn,$worksheet->getCellByColumnAndRow(3,$row)->getValue());
			$sql= "INSERT INTO attendance_tl(Emp_ID, Month, Year, Absent_Days) VALUES ('.$Emp_ID.', '.$Month.', '.$Year.', '.$Absent_Days.')";
			mysqli_query($conn, $sql);
			//$html.='<td>' .$Emp_ID. '</td>';
			//$html.='<td>' .$Month. '</td>';
			//$html.='<td>' .$Year. '</td>';
			//$html.='<td>' .$Absent_Days. '</td>';
			//$html.= "</tr>";
		}
	}
	//$html .= '</table>';
	//echo $html;
	echo '<br /> Data Inserted';
}
?>


<html>
<head>
	
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {background-color: #F8F8F9;}


.button {
    background-color: #998AD4;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
	border-radius: 4px;
    margin: 4px 2px;
    cursor: pointer;
}
</style>
</head>
<body>
     <form>
        <div>
            <fieldset> <input onclick="window.location.href = 'sign-in.php'" class="button" type="button"  style="float: right;" value="Logout" />
                <legend></legend>
                <h2>Administrator</h2>
                <hr />
                            <input onclick="window.location.href = 'index.php'" class="button" type="button" value="Add Employee" />
							</br>
                                  <input onclick="window.location.href = 'view_department_details.php'" class="button" type="button" value="View Department" /> </br>
                            <input onclick="window.location.href = 'view_designation.php'" class="button" type="button" value="View Designation" /> </br>
							
                        
                            <input onclick="window.location.href = 'view_employee_details.php'" class="button" type="button" value="View Employee" /> </br>
                            <input onclick="window.location.href = 'paysliptable.php'"  name = "done" class="button" type="button" value=" Generate Pay Slip" /> </br>
							<input onclick="window.location.href = 'adminforum.php'"  class="button" type="button" value="View Message" />
							
            </fieldset>
        </div>
    </form>
</body>
</html>