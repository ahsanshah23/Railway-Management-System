-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2018 at 12:33 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mypayroll`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance_tl`
--

CREATE TABLE `attendance_tl` (
  `Emp_ID` int(11) NOT NULL,
  `Month` int(11) NOT NULL,
  `Year` int(11) NOT NULL,
  `Absent_Days` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance_tl`
--

INSERT INTO `attendance_tl` (`Emp_ID`, `Month`, `Year`, `Absent_Days`) VALUES
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2),
(1, 6, 2018, 7),
(2, 6, 2018, 3),
(3, 6, 2018, 6),
(4, 6, 2018, 3),
(5, 6, 2018, 1),
(6, 6, 2018, 5),
(7, 6, 2018, 0),
(8, 6, 2018, 0),
(9, 6, 2018, 2),
(10, 6, 2018, 2);

-- --------------------------------------------------------

--
-- Table structure for table `department_tl`
--

CREATE TABLE `department_tl` (
  `Dept_ID` int(11) NOT NULL,
  `Dept_Name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department_tl`
--

INSERT INTO `department_tl` (`Dept_ID`, `Dept_Name`) VALUES
(1, 'accounting'),
(2, 'finance'),
(3, 'sales'),
(4, 'HR'),
(5, 'marketing'),
(6, 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `designation_tl`
--

CREATE TABLE `designation_tl` (
  `Designation_ID` int(11) NOT NULL,
  `Designation_Name` varchar(20) NOT NULL,
  `Basic_Sal` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designation_tl`
--

INSERT INTO `designation_tl` (`Designation_ID`, `Designation_Name`, `Basic_Sal`) VALUES
(1, 'Junior _Officer', 40000),
(2, 'Senior_Officer', 55000),
(3, 'Junior_Manager', 75000),
(4, 'Senior_Manager', 90000),
(5, 'Department_Head', 100000),
(6, 'General_Manager', 110000);

-- --------------------------------------------------------

--
-- Table structure for table `employee_tl`
--

CREATE TABLE `employee_tl` (
  `Emp_ID` int(20) NOT NULL,
  `Emp_Name` varchar(20) NOT NULL,
  `Emp_Father_Name` varchar(20) NOT NULL,
  `Emp_DOB` date NOT NULL,
  `Emp_Age` int(20) NOT NULL,
  `Dept_ID` int(20) NOT NULL,
  `Designation_ID` int(20) NOT NULL,
  `Emp_Date` date NOT NULL,
  `Emp_CNIC` int(13) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `AccountNumber` int(30) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_tl`
--

INSERT INTO `employee_tl` (`Emp_ID`, `Emp_Name`, `Emp_Father_Name`, `Emp_DOB`, `Emp_Age`, `Dept_ID`, `Designation_ID`, `Emp_Date`, `Emp_CNIC`, `Email`, `AccountNumber`, `Password`) VALUES
(2, 'ahsan', 'shah', '2018-12-02', 12, 1, 2, '2018-12-04', 123, 'a@gmail.com', 123, '202cb962ac59075b964b07152d234b70'),
(3, 'aa', 'aa', '2018-12-02', 12, 1, 4, '2018-12-02', 12, 'a@gmail.com', 12, 'c20ad4d76fe97759aa27a0c99bff6710');

-- --------------------------------------------------------

--
-- Table structure for table `emp_allow_tl`
--

CREATE TABLE `emp_allow_tl` (
  `Designation_ID` int(11) NOT NULL,
  `Medical_Allowance` int(11) NOT NULL,
  `House_Rent` int(11) NOT NULL,
  `Utility_Allowance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_allow_tl`
--

INSERT INTO `emp_allow_tl` (`Designation_ID`, `Medical_Allowance`, `House_Rent`, `Utility_Allowance`) VALUES
(1, 500, 5000, 2000),
(2, 500, 5000, 2000),
(3, 700, 5000, 2000),
(4, 900, 5000, 2000),
(5, 1100, 5000, 2000),
(6, 1300, 5000, 2000),
(7, 1500, 5000, 2000),
(8, 500, 5000, 2000),
(19, 600, 2000, 2000),
(20, 500, 3000, 2000),
(21, 200, 2000, 2000),
(22, 100, 4500, 2000),
(23, 500, 5000, 2000),
(24, 500, 5000, 2000),
(25, 500, 5000, 2000),
(26, 500, 5000, 2000),
(27, 500, 4000, 2000),
(28, 500, 5800, 2000),
(29, 500, 5000, 2000),
(30, 500, 5000, 2000),
(31, 500, 5000, 2000),
(32, 500, 5000, 2000),
(33, 500, 5000, 2000),
(34, 500, 5000, 2000),
(35, 500, 5500, 2000),
(36, 500, 5000, 2000),
(37, 500, 5600, 2000),
(38, 500, 2000, 2000),
(39, 500, 1000, 2000),
(40, 500, 5000, 2000),
(41, 500, 5000, 2000),
(42, 500, 5000, 2000),
(43, 500, 5000, 2000),
(44, 550, 1000, 2000),
(45, 900, 3000, 2000),
(46, 100, 3000, 2000),
(47, 500, 2000, 2000),
(48, 650, 7000, 2000),
(49, 550, 7000, 2000),
(50, 500, 5000, 2000);

-- --------------------------------------------------------

--
-- Table structure for table `emp_ded_tl`
--

CREATE TABLE `emp_ded_tl` (
  `Emp_ID` int(20) NOT NULL,
  `PF` int(50) NOT NULL,
  `Tax` decimal(50,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_ded_tl`
--

INSERT INTO `emp_ded_tl` (`Emp_ID`, `PF`, `Tax`) VALUES
(1, 400, '4000'),
(2, 400, '4000'),
(3, 400, '5000'),
(4, 400, '6000'),
(5, 450, '555'),
(6, 350, '575'),
(7, 480, '123'),
(8, 96, '635'),
(9, 18, '555'),
(10, 450, '555'),
(11, 820, '115'),
(12, 970, '125'),
(13, 190, '555'),
(14, 230, '555'),
(15, 450, '555'),
(16, 450, '765'),
(17, 450, '555'),
(18, 650, '532'),
(19, 430, '555'),
(20, 450, '555'),
(21, 670, '567'),
(22, 320, '512'),
(23, 450, '555'),
(24, 450, '555'),
(25, 450, '555'),
(26, 409, '335'),
(27, 310, '985'),
(28, 90, '1000'),
(29, 230, '295'),
(30, 980, '122'),
(31, 450, '323'),
(32, 450, '555'),
(33, 350, '435'),
(34, 344, '435'),
(35, 450, '555'),
(36, 450, '555'),
(37, 450, '555'),
(38, 450, '555'),
(39, 450, '975'),
(40, 450, '435'),
(41, 450, '555'),
(42, 450, '555'),
(43, 450, '555'),
(44, 450, '995'),
(45, 120, '118'),
(46, 170, '533'),
(47, 560, '125'),
(48, 130, '315'),
(49, 421, '521'),
(50, 443, '765');

-- --------------------------------------------------------

--
-- Table structure for table `leave_tl`
--

CREATE TABLE `leave_tl` (
  `Emp_ID` int(11) NOT NULL,
  `Sick_Leave` int(11) NOT NULL,
  `Casual_Leave` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leave_tl`
--

INSERT INTO `leave_tl` (`Emp_ID`, `Sick_Leave`, `Casual_Leave`) VALUES
(3, 4, 6),
(4, 4, 6),
(1, 4, 0),
(2, 6, 5),
(19, 2, 0),
(20, 1, 2),
(19, 2, 0),
(19, 2, 0),
(20, 1, 2),
(21, 1, 2),
(22, 1, 2),
(23, 1, 2),
(24, 1, 2),
(25, 1, 2),
(26, 1, 1),
(27, 1, 2),
(28, 4, 1),
(29, 1, 5),
(30, 1, 9),
(31, 1, 2),
(32, 2, 2),
(33, 1, 2),
(34, 1, 2),
(35, 1, 2),
(36, 1, 2),
(37, 1, 2),
(38, 6, 7),
(39, 0, 0),
(40, 1, 2),
(41, 1, 2),
(42, 1, 2),
(43, 1, 2),
(44, 1, 2),
(45, 1, 2),
(46, 0, 0),
(47, 1, 0),
(48, 0, 2),
(49, 0, 2),
(50, 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `month_tl`
--

CREATE TABLE `month_tl` (
  `Month` int(11) NOT NULL,
  `Days` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `month_tl`
--

INSERT INTO `month_tl` (`Month`, `Days`) VALUES
(1, 31),
(2, 28),
(3, 31),
(4, 30),
(5, 31),
(6, 30),
(7, 31),
(8, 31),
(9, 30),
(10, 31),
(11, 30),
(12, 31);

-- --------------------------------------------------------

--
-- Table structure for table `payslip`
--

CREATE TABLE `payslip` (
  `Emp_ID` int(30) NOT NULL,
  `Department` varchar(30) NOT NULL,
  `Designation` varchar(30) NOT NULL,
  `Medical_Allow` int(30) NOT NULL,
  `House_Rent` int(30) NOT NULL,
  `Utility_Allowance` int(30) NOT NULL,
  `Provident_Fund` int(30) NOT NULL,
  `Tax` int(30) NOT NULL,
  `Basic_Salary` int(30) NOT NULL,
  `Gross_Salary` int(30) NOT NULL,
  `Total_Ded` int(30) NOT NULL,
  `Net_Salary` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payslip`
--

INSERT INTO `payslip` (`Emp_ID`, `Department`, `Designation`, `Medical_Allow`, `House_Rent`, `Utility_Allowance`, `Provident_Fund`, `Tax`, `Basic_Salary`, `Gross_Salary`, `Total_Ded`, `Net_Salary`) VALUES
(2, 'accounting', 'Senior_Officer', 500, 5000, 2000, 400, 4000, 55000, 42167, 15400, 26767),
(3, 'accounting', 'Senior_Manager', 900, 5000, 2000, 400, 5000, 90000, 65900, 32404, 33496);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department_tl`
--
ALTER TABLE `department_tl`
  ADD PRIMARY KEY (`Dept_ID`);

--
-- Indexes for table `designation_tl`
--
ALTER TABLE `designation_tl`
  ADD PRIMARY KEY (`Designation_ID`),
  ADD UNIQUE KEY `Basic_Sal` (`Designation_ID`);

--
-- Indexes for table `employee_tl`
--
ALTER TABLE `employee_tl`
  ADD PRIMARY KEY (`Emp_ID`);

--
-- Indexes for table `month_tl`
--
ALTER TABLE `month_tl`
  ADD PRIMARY KEY (`Month`);

--
-- Indexes for table `payslip`
--
ALTER TABLE `payslip`
  ADD UNIQUE KEY `Emp_ID` (`Emp_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `department_tl`
--
ALTER TABLE `department_tl`
  MODIFY `Dept_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `designation_tl`
--
ALTER TABLE `designation_tl`
  MODIFY `Designation_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employee_tl`
--
ALTER TABLE `employee_tl`
  MODIFY `Emp_ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
