<?php
$conn = mysqli_connect('localhost', 'root', '','mypayroll');

if($conn-> connect_error)
{
	echo "connection failed";
}


$UserName = $_GET['UserName'];
$query = "SELECT Emp_Name from employee_tl where Emp_ID = '$UserName'";
	$Name1 = mysqli_query($conn,$query);
	$result = mysqli_fetch_row($Name1);
	$Name = $result[0];
	

if (isset($_POST['done']))
{
	$input = $_POST['input'];
	$dataString = $UserName;
	$dataString.= ":";
	$dataString.= $Name;
	$dataString.= " ";
	$dataString.= " ";
	$dataString .= $input;

$dataString .= "\n";

$fWrite = fopen("forum.txt","at");

$wrote = fwrite($fWrite, $dataString);

fclose($fWrite);


echo "<script language='javascript' type='text/javascript'>";
echo "alert('Your message has been sent to the administrator');";
echo "</script>";
header("refresh:2; url=employee.php?UserName=$UserName");

	
	
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {background-color:#F8F8F9;}

#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

.button {
    background-color: #998AD4;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
	border-radius: 4px;
    margin: 4px 2px;
    cursor: pointer;
}
#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #998AD4;
    color: white;
}
#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}
#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}
</style>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <fieldset>
						<input onclick="window.location.href = 'employee.php?UserName=<?php echo $UserName ?>'" class="button" type="button" style="float: right;" value="Back" />
						<legend></legend>
<html >
<head>
  <meta charset="UTF-8">
  <title></title>
  <link href='https://fonts.googleapis.com/css?family=Lora|Ubuntu:300,400' rel='stylesheet' type='text/css'>
  
  
      <link rel="stylesheet" href="forum12.css">

  
</head>

<body>
  <h1>Compose Message</h1>
<form method="post">
  <textarea name="input" rows="2" class="question" id="msg" required autocomplete="off"></textarea>
  <label for="msg"><span>What's your message?</span></label>
  <input type="submit" value="Submit!" name="done"/>
</form>
  
  
</body>
</html>
