<html lang="en">
<head>
<style>
.button {
    background-color: #998AD4;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
	border-radius: 4px;
    margin: 4px 2px;
    cursor: pointer;
} </style>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    <style type="text/css">
      
    </style>
    <script type="text/javascript">
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>
</head>
<body>
	<form>
		<div>
			<fieldset>
					<input onclick="window.location.href = 'admin.html'" class="button" type="button" style="float: right;" value="Back" />
					<input onclick="window.location.href = 'create.php'" class="button" type="button" style="float: right;" value="Add New Employee" />
					<legend></legend>
					<h2>Pay Slip Details  </h2>
					<hr />
                    <?php
                    $conn = mysqli_connect('localhost', 'root', '','mypayroll');

                    if($conn-> connect_error)
					{
	                  echo "connection failed";
                    }

                    
                    // Attempt select query execution
					
                    $sql = "SELECT * FROM employee_tl";
                    if($result = mysqli_query($conn, $sql)){
                        if(mysqli_num_rows($result) > 0)
						{
                            echo "<table class='table table-bordered table-striped'>";
                                echo "<thead>";
                                    echo "<tr>";
                                        echo "<th>ID</th>";
                                        echo "<th>Name</th>";
                                        echo "<th>Father Name</th>";
                                        echo "<th>DOB</th>";
										echo "<th>Age</th>";
										echo "<th>Department ID</th>";
										echo "<th>Designation ID</th>";
										echo "<th>Start Date</th>";
										echo "<th>CNIC</th>";
										echo "<th>Email</th>";
										echo "<th>Account Number</th>";
										echo "<th>Manager ID</th>";
                                    echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";
                                while($row = mysqli_fetch_array($result)){
                                    echo "<tr>";
                                        echo "<td>" . $row['Emp_ID'] . "</td>";
                                        echo "<td>" . $row['Emp_Name'] . "</td>";
                                        echo "<td>" . $row['Emp_Father_Name'] . "</td>";
                                        echo "<td>" . $row['Emp_DOB'] . "</td>";
										echo "<td>" . $row['Emp_Age'] . "</td>";
										echo "<td>" . $row['Dept_ID'] . "</td>";
										echo "<td>" . $row['Designation_ID'] . "</td>";
										echo "<td>" . $row['Emp_Date'] . "</td>";
										echo "<td>" . $row['Emp_CNIC'] . "</td>";
										echo "<td>" . $row['Email'] . "</td>";
										echo "<td>" . $row['AccountNumber'] . "</td>";
										echo "<td>" . $row['MgrSsn'] . "</td>";
                                        echo "<td>";
                                        echo "<a href='update.php?id=". $row['Emp_ID'] ."' title='Update Record' data-toggle='tooltip'><span class='glyphicon glyphicon-pencil'></span></a>";
                                        echo "<a href='delete.php?id=". $row['Emp_ID'] ."' title='Delete Record' data-toggle='tooltip'><span class='glyphicon glyphicon-trash'></span></a>";
                                        echo "</td>";
                                    echo "</tr>";
                                }
                                echo "</tbody>";                            
                            echo "</table>";
                            // Free result set
                            mysqli_free_result($result);
                        } else{
                            echo "<p class='lead'><em>No records were found.</em></p>";
                        }
                    } else{
                        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
                    }
 0
                    // Close connection
                    //$conn->close();
                    ?>
				
                </fieldset>
            </div>        
        </form>
	</body>
</html>