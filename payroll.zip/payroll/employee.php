<html>
<head>
<style>
body {background-color: #F8F8F9;}


.button {
    background-color: #998AD4;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
	border-radius: 4px;
    margin: 4px 2px;
    cursor: pointer;
}
</style>
    <title></title>
</head>
<body>
    <form>
        <div>
		
						<?php 
						$conn = mysqli_connect('localhost', 'root', '','mypayroll');

if($conn-> connect_error)
{
	echo "connection failed";
}$ID = $_GET['UserName']; 
				
$query = "SELECT Emp_Name from employee_tl where Emp_ID = '$ID'";
	$Name1 = mysqli_query($conn,$query);
	$result = mysqli_fetch_row($Name1);
	$Name = $result[0];?>
	
            <fieldset>  <input onclick="window.location.href = 'sign-in.php'" class="button" type="button"  style="float: right;" value="Logout" />
                <legend></legend>
				<table>
                
				<blockquote><td><h2>Welcome <?php echo "$Name" ?></td> 
                </table><hr />
				

                <table>
                    <tr>
                        <td>
                            <input  class="button" onclick="window.location.href = 'employeeprofile.php?UserName=<?php echo "$ID" ?>'" type="button" value="View Profile" />
                        </td>
                    </tr>
					
					<tr>
                        <td>
                            <input class="button"  onclick="window.location.href = 'forum.php?UserName=<?php echo "$ID" ?>'" type="button" value="Compose Message" />
                        </td>
                    </tr>
                </table>
            </fieldset>
        </div>
    </form>
</body>
</html>

