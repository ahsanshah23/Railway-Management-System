<html>
<head>
    <title></title>
</head>
<body>
    <form>
        <div>
            <fieldset>
                <legend></legend>
                <h2>Attendance Details</h2>
                <hr />
				<table>
				<tr><blockquote> 
					<th><p>Emp_ID</p></th>
					<th><p>Month</p></th>
					<th><p>Year</p></th>
					<th><p>Absent Days</p></th>
				</blockquote> </tr>
			</fieldset>
        </div>
    </form>
</body>
</html>
