<?php
$conn = mysqli_connect('localhost', 'root', '','mypayroll');

if($conn-> connect_error)
{
	echo "connection failed";
}

// Define variables and initialize with empty values
$Emp_ID = $Emp_Name = $Emp_Father_Name = $Emp_DOB = $Emp_Age = $Dept_ID = $Designation_ID = $Emp_Date = $Emp_CNIC = $MgrSsn = "";
$Emp_ID_err = $Emp_Name_err = $Emp_Father_Name_err = $Emp_DOB_err = $Emp_Age_err = $Dept_ID_err = $Designation_ID_err = $Emp_Date_err = $Emp_CNIC_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $Designation_Name = $_POST["Designation_Name"];
	$Dept_Name = $_POST["Dept_Name"];
    $Emp_Name = trim($_POST["Emp_Name"]);
    $Emp_Father_Name = trim($_POST["Emp_Father_Name"]);
    $Emp_DOB = trim($_POST["Emp_DOB"]);
   
	$Password = md5($_POST['Password']);
	$Email = $_POST['Email'];
	$AccountNumber = $_POST['AccountNumber'];
	$MgrSsn = $_POST['MgrSsn'];
	
	
    $Emp_Age = (date('Y') - date('Y',strtotime($Emp_DOB)));
    
	
    $query = "SELECT Dept_ID from department_tl where Dept_Name = '$Dept_Name'";
	$Dept_ID = mysqli_query($conn,$query);
	$result = mysqli_fetch_row($Dept_ID);
	$result1 = $result[0];
	
	
	$query1 = "SELECT Designation_ID from designation_tl where Designation_Name = '$Designation_Name'";
	$Designation_ID = mysqli_query($conn,$query1);
	$result2 = mysqli_fetch_row($Designation_ID);
	$result3 = $result2[0];
	

	//if($Designation_ID == 0)
	//{
	//	$Designation_ID = 1;
	//}
	
    $Emp_Date = trim($_POST["Emp_Date"]);
    $Emp_CNIC = trim($_POST["Emp_CNIC"]);
   
    
    // Check input errors before inserting in database
    
        $sql = "INSERT INTO employee_tl(Emp_Name,Emp_Father_Name,Emp_DOB,Emp_Age,Dept_ID,Designation_ID,Emp_Date,Emp_CNIC,Email, AccountNumber, Password, MgrSsn) 
        VALUES ('$Emp_Name','$Emp_Father_Name','$Emp_DOB','$Emp_Age','$result1','$result3','$Emp_Date','$Emp_CNIC','$Email','$AccountNumber', '$Password', '$MgrSsn')"; 
        
		// Attempt to execute the prepared queury
		if(mysqli_query ($conn, $sql))
		{
			// Records created successfully. Redirect to landing page
				
               header("location: salary.php");
		}
		else
		{
			echo "error";
		}
		
    
    
    // Close connection
    $conn->close();
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Create Record</h2>
                    </div>
                    <p>Please fill this form and submit to add employee record to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($Emp_Name_err)) ? 'has-error' : ''; ?>">
                            <label>Name</label>
                            <input type="text" name="Emp_Name" class="form-control" value="<?php echo $Emp_Name; ?>"  required/>
                            <span class="help-block"><?php echo $Emp_Name_err;?></span>
                        </div>
						<div class="form-group <?php echo (!empty($Emp_Father_Name_err)) ? 'has-error' : ''; ?>">
                            <label>Father Name</label>
                            <input type="text" name="Emp_Father_Name" class="form-control" value="<?php echo $Emp_Father_Name; ?>" required/>
                            <span class="help-block"><?php echo $Emp_Father_Name_err;?></span>
                        </div>
						<div class="form-group <?php echo (!empty($Emp_DOB_err)) ? 'has-error' : ''; ?>">
                            <label>DOB</label>
                            <input type="date" name="Emp_DOB" class="form-control" value="<?php echo $Emp_DOB; ?>" required/>
                            <span class="help-block"><?php echo $Emp_DOB_err;?></span>
                        </div>
					
						<div class="form-group ">
                            <label>Department</label>
							<select name="Dept_Name">
								<option value="accounting">ACCOUNTING</option>
								<option value="sales">SALES</option>
								<option value="marketing">MARKETING</option>
								<option value="finance">finance</option>
								<option value="IT">IT</option>
								<option value="HR">HR</option>
							</select>
                            <span class="help-block"><?php echo $Dept_ID_err;?></span>
                        </div>
						<div class="form-group ">
                            <label>Designation</label>
                            <select name="Designation_Name" >
								<option value="Junior_Officer">Junior_Officer</option>
								<option value="Senior_Officer">Senior_Officer</option>
								<option value="Junior_Manager">Junior_Manager</option>
								<option value="Senior_Manager">Senior_Manager</option>
								<option value="Department_Head">Department_Head</option>
								<option value="General_Manager">General_Manager</option>
							</select>
                            <span class="help-block"><?php echo $Designation_ID_err;?></span>
                        </div>
						<div class="form-group <?php echo (!empty($Emp_Date_err)) ? 'has-error' : ''; ?>">
                            <label>Start Date</label>
                            <input required type="date" name="Emp_Date" class="form-control"><?php echo $Emp_Date; ?> </input>
                            <span class="help-block"><?php echo $Emp_Date_err;?></span>
                        </div>
						<div class="form-group <?php echo (!empty($Emp_CNIC_err)) ? 'has-error' : ''; ?>">
                            <label>CNIC</label>
                            <input type="number" name="Emp_CNIC" class="form-control" value="<?php echo $Emp_CNIC; ?>"  required/>
                            <span class="help-block"><?php echo $Emp_CNIC_err;?></span>
                        </div>
						<div class="form-group">
                            <label>Email</label>
                            <input type="email" name="Email" class="form-control"  required/>
                            <span class="help-block"></span>
                        </div>
						
						<div class="form-group">
                            <label>Account Number</label>
                            <input type="number" name="AccountNumber" class="form-control"  required/>
                            <span class="help-block"></span>
                        </div>
						
						<div class="form-group ">
                            <label>Password</label>
                            <input type="password" name="Password" class="form-control" required/ >
                            <span class="help-block"></span>
                        </div>
						<div class="form-group ">
                            <label>Manager</label>
                            <input type="number" name="MgrSsn" class="form-control" >
                            <span class="help-block"></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Submit" required/>
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>