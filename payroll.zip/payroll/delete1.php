<?php
$conn = mysqli_connect('localhost', 'root', '','mypayroll');

if($conn-> connect_error)
{
	echo "connection failed";
}
else
{
	echo "connected";
}

if(!mysqli_select_db($conn, 'mypayroll'))
{
	echo 'database not selected';
}
else{
	echo "selected";
}



$ID = $_GET['id'];

	$delete = "DELETE FROM employee_tl WHERE Emp_ID=$ID";
    $delete1 = "DELETE FROM payslip WHERE Emp_ID=$ID";
	mysqli_query ($conn, $delete);
	if(mysqli_query ($conn, $delete1))
	{
		echo "deleted";
		header("location:index.php");
	}
	else
	{
		echo "error";
	}

?>