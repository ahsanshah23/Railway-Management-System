<?php

$conn = mysqli_connect('localhost', 'root', '','mypayroll');

    if($conn-> connect_error)
	{
	    echo "connection failed";
    }
	
	$ID = $_GET['id'];

	// email work
	$Email0="select Email from employee_tl where Emp_ID='$ID'";
	$Email1=mysqli_query($conn,$Email0);
	$Email2=mysqli_fetch_row($Email1);
	$Email=$Email2[0];
	//echo $Email;

	$Emp_Name0="select Emp_Name from employee_tl where Emp_ID='$ID'";
	$Emp_Name1=mysqli_query($conn,$Emp_Name0);
	$Emp_Name2=mysqli_fetch_row($Emp_Name1);
	$Emp_Name=$Emp_Name2[0];
	//echo $Emp_Name;




	
	
	$sql="select Emp_Name from employee_tl where Emp_ID='$ID'";
	$result=mysqli_query($conn,$sql);
	$row=mysqli_fetch_row($result);
	$Emp_Name=$row[0];
	
	$sql1="select Department from payslip where Emp_ID='$ID'";
	$result1=mysqli_query($conn, $sql1);
	$row1=mysqli_fetch_row($result1);
	$Department=$row1[0];
	
	$sql2="select Designation from payslip where Emp_ID='$ID'";
	$result2=mysqli_query($conn, $sql2);
	$row2=mysqli_fetch_row($result2);
	$Designation=$row2[0];
	
	//Earnings
	$sql3="select Medical_Allow from payslip where Emp_ID='$ID'";
	$result3=mysqli_query($conn, $sql3);
	$row3=mysqli_fetch_row($result3);
	$Medical_Allow=$row3[0];
	
	$sql4="select House_Rent from payslip where Emp_ID='$ID'";
	$result4=mysqli_query($conn, $sql4);
	$row4=mysqli_fetch_row($result4);
	$House_Rent=$row4[0];
	
	$sql5="select Utility_Allowance from payslip where Emp_ID='$ID'";
	$result5=mysqli_query($conn, $sql5);
	$row5=mysqli_fetch_row($result5);
	$Utility_Allowance=$row5[0];
	
	$sql6="select Basic_Salary from payslip where Emp_ID='$ID'";
	$result6=mysqli_query($conn, $sql6);
	$row6=mysqli_fetch_row($result6);
	$Basic_Salary=$row6[0];
	
	$sql9="select Gross_Salary from payslip where Emp_ID='$ID'";
	$result9=mysqli_query($conn, $sql9);
	$row9=mysqli_fetch_row($result9);
	$Gross_Salary=$row9[0];
	
	//Deductions
	
	$sql7="select Provident_Fund from payslip where Emp_ID='$ID'";
	$result7=mysqli_query($conn, $sql7);
	$row7=mysqli_fetch_row($result7);
	$Provident_Fund=$row7[0];
	
	$sql8="select Tax from payslip where Emp_ID='$ID'";
	$result8=mysqli_query($conn, $sql8);
	$row8=mysqli_fetch_row($result8);
	$Tax=$row8[0];
	
	
	
	//Net deductions
	
	$sql10="select Total_Ded from payslip where Emp_ID='$ID'";
	$result10=mysqli_query($conn, $sql10);
	$row10=mysqli_fetch_row($result10);
	$Total_Ded=$row10[0];
	
	//Net Salary
	
	$sql11="select Net_Salary from payslip where Emp_ID='$ID'";
	$result11=mysqli_query($conn, $sql11);
	$row11=mysqli_fetch_row($result11);
	$Net_Salary=$row11[0];
	
	//total earnings
	$totalearnings = $Medical_Allow+$House_Rent+$Utility_Allowance+$Basic_Salary+$Gross_Salary;
	
	
	if(isset($_POST["action"]))
{
	include('pdf.php');
	$file_name = md5(rand()) . '.pdf';
	$html_code = '<link rel="stylesheet" href="bootstrap.min.css">';
	$html_code .= fetch_customer_data($connect);
	$pdf = new Pdf();
	$pdf->load_html($html_code);
	$pdf->render();
	$file = $pdf->output();
	file_put_contents($file_name, $file);
	
	require 'class/class.phpmailer.php';
	$mail = new PHPMailer;
	$mail->IsSMTP();								//Sets Mailer to send message using SMTP
	$mail->Host = 'smtp.gmail.com';		//Sets the SMTP hosts of your Email hosting, this for Godaddy
	$mail->Port = '587';								//Sets the default SMTP server port
	$mail->SMTPAuth = true;							//Sets SMTP authentication. Utilizes the Username and Password variables
	$mail->Username = 'sarashakil21@gmail.com';					//Sets SMTP username
	$mail->Password = 'SofcomIntern..8';					//Sets SMTP password
	$mail->SMTPSecure = 'tls';							//Sets connection prefix. Options are "", "ssl" or "tls"
	$mail->From = 'sarashakil21@gmail.com';			//Sets the From email address for the message
	$mail->FromName = 'Sara Shakil';			//Sets the From name of the message
	$mail->AddAddress($Email, $Emp_Name);		//Adds a "To" address
	$mail->WordWrap = 50;							//Sets word wrapping on the body of the message to a given number of characters
	$mail->IsHTML(true);							//Sets message type to HTML				
	$mail->AddAttachment($file_name);     				//Adds an attachment from a path on the filesystem
	$mail->Subject = 'Customer Details';			//Sets the Subject of the message
	$mail->Body = 'Please Find Customer details in attach PDF File.';				//An HTML or plain text message body
	if($mail->Send())								//Send an Email. Return true on success or false on error
	{
		$message = '<label class="text-success">Payslip has been sent successfully...</label>';
	}
	unlink($file_name);
}

	

?>

<html>
<head>
    <title></title>
</head>
<body>
<form method="post">
				<input type="submit" name="action" class="btn btn-danger" value="PDF Send" /><?php echo $message; ?>
			</form>
    <form>
        <div>
            <h2>PAYSLIP</h2>
            <fieldset>
                <legend></legend>
                <fieldset>
                    <legend></legend>
                    <table>
                        <tr>
                            <td><label>Employee ID:</label></td>
							<td><?php echo "$ID";?></td>
							

                            <td><label>Name:</label></td>
							<td><?php echo "$Emp_Name";?></td>
                            
                        </tr>
                        <tr>
                            <td><label>Department:</label></td>
							<td><?php echo "$Department";?></td>
                            
                            <td><label>Designation:</label></td>
							<td><?php echo "$Designation";?></td>
                           
                        
                    </table>
                </fieldset>
                <fieldset>
                    <legend></legend>
                    <table>
                        <tr>
                            <td>Earnings</td>
                            <td>Amount</td>

                            <td>Deductions</td>
                            <td>Amount</td>
                        </tr>
                        <tr>
                            <td><hr /></td>
                            <td><hr /></td>

                            <td><hr /></td>
                            <td><hr /></td>
                        </tr>
                        <tr>
                            <td><label>Medical_Allowance: </label></td>
                            <td><?php echo "$Medical_Allow";?></td>

                            <td><label>Provident_Fund</label></td>
                            <td><?php echo "$Provident_Fund";?></td>
                        </tr>
                        <tr>
                            <td><label>House_Rent:</label></td>
                            <td><?php echo "$House_Rent";?></td>

                            <td><label>Tax:</label></td>
                            <td><?php echo "$Tax";?></td>
                        </tr>
                        <tr>
                            <td><label>Utility_Allowance:</label></td>
                            <td><?php echo "$Utility_Allowance";?></td>

                            
                        </tr>
                        <tr>
                            <td><label>Basic_Salary:</label></td>
                            <td><?php echo "$Basic_Salary";?></td>
                        </tr>
                       
                       
                        <tr>
                            <td><hr /></td>
                            <td><hr /></td>

                            <td><hr /></td>
                            <td><hr /></td>
                        </tr>
                        <tr>
                            <td><label>Gross_Salary:</label></td>
                            <td><?php echo "$Gross_Salary";?></td>

                            <td><label>Total Deductions:</label></td>
                            <td><?php echo "$Total_Ded";?></td>
							</tr>
                        </tr>
							<td><label>Net_Salary:</label></td>
                            <td><?php echo "$Net_Salary";?></td>
						</tr>
						
						
                    </table>
                </fieldset>
            </fieldset>
        </div>
    </form>
</body>
</html>

