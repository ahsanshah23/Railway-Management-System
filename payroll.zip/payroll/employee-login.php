<!DOCTYPE html>
<html>
<head>
<style>
body {background-color:#F8F8F9;} 
.button {
    background-color: #998AD4;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
	border-radius: 4px;
    cursor: pointer;
	
}

fieldset { 
  display: block;
    margin-left: 2px;
    margin-right: 2px;
    padding-top: 0.35em;
    padding-bottom: 0.625em;
    padding-left: 0.75em;
    padding-right: 0.75em;
    border: 2px groove (internal value);
	width: 400px;
    
  margin:auto; }
		
    
 
}
#legend {
font-size: 1.4em;
text-transform: uppercase;
color: #000;
}
</style>
<header class="header-basic-light">		<title>Payroll System</title>
    <script src="adminLogin.js"></script>
	<link rel="stylesheet" href="assets/demo.css">
	<link rel="stylesheet" href="assets/header-basic-light.css">
	<link href='http://fonts.googleapis.com/css?family=Cookie' rel='stylesheet' type='text/css'>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">





	<div class="header-limiter">

		<h1><a href="index.php">Payroll <span>Management</span></a></h1>

		<nav>
		<a href="sign-in.php" >HOME</a>
			<a href="employee-login.php" class="selected" >EMPLOYEE</a>
			<a href="admin-login.php" >ADMIN</a>
			<a href="manager-login.php">MANAGER</a>
			

		</nav>
	</div>
	</header>
<?php
$con = mysqli_connect('localhost', 'root', '','mypayroll');

if(isset($_POST['done']))
{
$username = $_POST['username'];
$password = md5($_POST['password']);

$sql1 = "select Designation_ID from employee_tl where Emp_ID=$username";
$result1= mysqli_query($con, $sql1);
$row1 = mysqli_fetch_row($result1);
$Des = $row1[0];

	if($Des=='0' OR $Des=='1' OR $Des=='2')
	{
		
		$sql= "SELECT * FROM employee_tl WHERE Emp_ID = '$username' AND Password = '$password' ";
		$result = mysqli_query($con,$sql);
		$check = mysqli_fetch_array($result);
		if(isset($check)){
			echo "<script >alert('success')</script>";
			header("location:employee.php?UserName=$username");
			echo 'success';
		}
		else
		{
			echo "<script language='javascript' type='text/javascript'>";
				echo "alert('ID or passwordnot correct');";
				echo "</script>";
			
		}
	}
	else
	{
		echo "<script language='javascript' type='text/javascript'>";
				echo "alert('This is not your valid log in destination');";
				echo "</script>";
				
	}
}

?>



<html>
<head>
    <title></title>
	
</head>
<body>
    <form method="post">
        <div>
            <fieldset id='color'>
                <legend></legend>
                  <h2>Employee</h2>
                    <hr />
                    <p>Username:<br />
                    <input type="text" name="username" id="username" />  
                    </p>
                    <p>Password:<br />
                        <input type="password" name="password" id="password"/>
                    </p>
					 <input name="done" class="button" type="submit" value="login" />
					</fieldset>
        </div>
    </form>
</body>
</html>
</head>
