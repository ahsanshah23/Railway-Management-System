<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {background-color:#F8F8F9;}

#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

.button {
    background-color: #998AD4;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
	border-radius: 4px;
    margin: 4px 2px;
    cursor: pointer;
}
#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #998AD4;
    color: white;
}
#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}
#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}
</style>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <fieldset>
						<input onclick="window.location.href = 'admin.html'" class="button" type="button" style="float: right;" value="Back" />
						<legend></legend>
<?php
$message = '';
$ID ='';
	$Emp_Name ='';
	$Department ='';
	$Email= '';

$conn = mysqli_connect('localhost', 'root', '','mypayroll');

    if($conn-> connect_error)
	{
	    echo "connection failed";
    }
	$ID = $_GET['id'];

	$Email0="select Email from employee_tl where Emp_ID='$ID'";
	$Email1=mysqli_query($conn,$Email0);
	$Email2=mysqli_fetch_row($Email1);
	$Email=$Email2[0];

	$Emp_Name0="select Emp_Name from employee_tl where Emp_ID='$ID'";
	$Emp_Name1=mysqli_query($conn,$Emp_Name0);
	$Emp_Name2=mysqli_fetch_row($Emp_Name1);
	$Emp_Name=$Emp_Name2[0];
	
	function fetch_customer_data($conn)
	{
		$ID = $_GET['id'];
		$sql="select Emp_Name from employee_tl where Emp_ID='$ID'";
	$result=mysqli_query($conn,$sql);
	$row=mysqli_fetch_row($result);
	$Emp_Name=$row[0];
	
	$sql1="select Department from payslip where Emp_ID='$ID'";
	$result1=mysqli_query($conn, $sql1);
	$row1=mysqli_fetch_row($result1);
	$Department=$row1[0];
	
	$sql2="select Designation from payslip where Emp_ID='$ID'";
	$result2=mysqli_query($conn, $sql2);
	$row2=mysqli_fetch_row($result2);
	$Designation=$row2[0];
	
	//Earnings
	$sql3="select Medical_Allow from payslip where Emp_ID='$ID'";
	$result3=mysqli_query($conn, $sql3);
	$row3=mysqli_fetch_row($result3);
	$Medical_Allow=$row3[0];
	
	$sql4="select House_Rent from payslip where Emp_ID='$ID'";
	$result4=mysqli_query($conn, $sql4);
	$row4=mysqli_fetch_row($result4);
	$House_Rent=$row4[0];
	
	$sql5="select Utility_Allowance from payslip where Emp_ID='$ID'";
	$result5=mysqli_query($conn, $sql5);
	$row5=mysqli_fetch_row($result5);
	$Utility_Allowance=$row5[0];
	
	$sql6="select Basic_Salary from payslip where Emp_ID='$ID'";
	$result6=mysqli_query($conn, $sql6);
	$row6=mysqli_fetch_row($result6);
	$Basic_Salary=$row6[0];
	
	$sql9="select Gross_Salary from payslip where Emp_ID='$ID'";
	$result9=mysqli_query($conn, $sql9);
	$row9=mysqli_fetch_row($result9);
	$Gross_Salary=$row9[0];
	
	//Deductions
	
	$sql7="select Provident_Fund from payslip where Emp_ID='$ID'";
	$result7=mysqli_query($conn, $sql7);
	$row7=mysqli_fetch_row($result7);
	$Provident_Fund=$row7[0];
	
	$sql8="select Tax from payslip where Emp_ID='$ID'";
	$result8=mysqli_query($conn, $sql8);
	$row8=mysqli_fetch_row($result8);
	$Tax=$row8[0];
	
	
	
	//Net deductions
	
	$sql10="select Total_Ded from payslip where Emp_ID='$ID'";
	$result10=mysqli_query($conn, $sql10);
	$row10=mysqli_fetch_row($result10);
	$Total_Ded=$row10[0];
	
	//Net Salary
	
	$sql11="select Net_Salary from payslip where Emp_ID='$ID'";
	$result11=mysqli_query($conn, $sql11);
	$row11=mysqli_fetch_row($result11);
	$Net_Salary=$row11[0];
	
	//total earnings
	$totalearnings = $Medical_Allow+$House_Rent+$Utility_Allowance+$Basic_Salary+$Gross_Salary;
	
	$output = '
	
	<div class="table-responsive">
            <fieldset>
                <legend></legend>
				<h2>PAYSLIP</h2>
                <hr />
                    <legend></legend>
                    <table>
                        <tr>
                            <td><label>ID:</label></td>
							<td>'."$ID".'</td>
							

                            <td><label>Name:</label></td>
							<td>'."$Emp_Name".'</td>
                            
                        </tr>
                        <tr>
                            <td><label>Department:</label></td>
							<td>'."$Department".'</td>
                            
                            <td><label>Designation:</label></td>
							<td>'."$Designation".'</td>
                           
                        
                    </table>
				</fieldset>
                <fieldset>
                    <legend></legend>
                    <table>
                        <tr>
                            <td>Earnings</td>
                            <td>Amount</td>

                            <td>Deductions</td>
                            <td>Amount</td>
                        </tr>
                        <tr>
                            <td><hr /></td>
                            <td><hr /></td>

                            <td><hr /></td>
                            <td><hr /></td>
                        </tr>
                        <tr>
                            <td><label>Medical Allowance: </label></td>
                            <td>'."$Medical_Allow".'</td>

                            <td><label>Provident Fund</label></td>
                            <td>'."$Provident_Fund".'</td>
                        </tr>
                        <tr>
                            <td><label>House Rent:</label></td>
                            <td>'."$House_Rent".'</td>

                            <td><label>Tax:</label></td>
                            <td>'."$Tax".'</td>
                        </tr>
                        <tr>
                            <td><label>Utility Allowance:</label></td>
                            <td>'."$Utility_Allowance".'</td>

                            
                        </tr>
                        <tr>
                            <td><label>Basic Salary:</label></td>
                            <td>'."$Basic_Salary".'</td>
                        </tr>
                       
                       
                        <tr>
                            <td><hr /></td>
                            <td><hr /></td>

                            <td><hr /></td>
                            <td><hr /></td>
                        </tr>
                        <tr>
                            <td><label>Gross Salary:</label></td>
                            <td>'."$Gross_Salary".'</td>

                            <td><label>Total Deductions:</label></td>
                            <td>'."$Total_Ded".'</td>
							</tr>
                        </tr>
							<td><label>Net Salary:</label></td>
                            <td>'."$Net_Salary".'</td>
						</tr>
						
						
                    </table>
                </fieldset>
            </fieldset>
        
	
	';
	$output .= '
	</div>
	';
	return $output;
}
	
	
	
	
	
	if(isset($_POST["action"]))
{
	//echo "hi";
	include('pdf.php');
	$file_name = md5(rand()) . '.pdf';
	$html_code = '<link rel="stylesheet" href="bootstrap.min.css">';
	$html_code .= fetch_customer_data($conn);
	$pdf = new Pdf();
	$pdf->load_html($html_code);
	$pdf->render();
	$file = $pdf->output();
	file_put_contents($file_name, $file);
	
	
	require 'class/class.phpmailer.php';
	$mail = new PHPMailer;
	$mail->IsSMTP();								//Sets Mailer to send message using SMTP
	$mail->Host = 'smtp.gmail.com';		//Sets the SMTP hosts of your Email hosting, this for Godaddy
	$mail->Port = '587';								//Sets the default SMTP server port
	$mail->SMTPAuth = true;							//Sets SMTP authentication. Utilizes the Username and Password variables
	$mail->Username = 'sarashakil21@gmail.com';					//Sets SMTP username
	$mail->Password = 'SofcomIntern..8';					//Sets SMTP password
	$mail->SMTPSecure = 'tls';							//Sets connection prefix. Options are "", "ssl" or "tls"
	$mail->From = 'sarashakil21@gmail.com';			//Sets the From email address for the message
	$mail->FromName = 'Sara Shakil';			//Sets the From name of the message
	$mail->AddAddress($Email, $Emp_Name);		//Adds a "To" address
	$mail->WordWrap = 50;							//Sets word wrapping on the body of the message to a given number of characters
	$mail->IsHTML(true);							//Sets message type to HTML				
	$mail->AddAttachment($file_name);     				//Adds an attachment from a path on the filesystem
	$mail->Subject = 'Payslip';			//Sets the Subject of the message
	$mail->Body = 'Please Find Payslip in attached PDF File.';	
	//An HTML or plain text message body
	//echo"sent";
	if($mail->Send())								//Send an Email. Return true on success or false on error
	{
		echo "<script language='javascript' type='text/javascript'>";
				echo "alert('Payslip has been sent successfully');";
				echo "</script>";
				header("refresh:2; url=admin.html");
		//$message = '<label class="text-success">Payslip has been sent successfully...</label>';
	}
	unlink($file_name);
}

	
	
	
	
	

?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

    <form   method="post">
	
				<input type="submit" name="action" class="button" value="PDF Send" /><?php echo $message; ?>
      <!--  <div>
            <h2>PAYSLIP</h2>
            <fieldset>
                <legend></legend>
                <fieldset>
                    <legend></legend>
                    <table>
                        <tr>
                            <td><label>Employee ID:</label></td>
							<td><?php echo "$ID";?></td>
							

                            <td><label>Name:</label></td>
							<td><?php echo "$Emp_Name";?></td>
                            
                        </tr>
                        <tr>
                            <td><label>Department:</label></td>
							<td><?php echo "$Department";?></td>
                            
                            <td><label>Designation:</label></td>
							<td><?php echo "$Designation";?></td>
                           
                        
                    </table>
                </fieldset>
                <fieldset>
                    <legend></legend>
                    <table>
                        <tr>
                            <td>Earnings</td>
                            <td>Amount</td>

                            <td>Deductions</td>
                            <td>Amount</td>
                        </tr>
                        <tr>
                            <td><hr /></td>
                            <td><hr /></td>

                            <td><hr /></td>
                            <td><hr /></td>
                        </tr>
                        <tr>
                            <td><label>Medical_Allowance: </label></td>
                            <td><?php echo "$Medical_Allow";?></td>

                            <td><label>Provident_Fund</label></td>
                            <td><?php echo "$Provident_Fund";?></td>
                        </tr>
                        <tr>
                            <td><label>House_Rent:</label></td>
                            <td><?php echo "$House_Rent";?></td>

                            <td><label>Tax:</label></td>
                            <td><?php echo "$Tax";?></td>
                        </tr>
                        <tr>
                            <td><label>Utility_Allowance:</label></td>
                            <td><?php echo "$Utility_Allowance";?></td>

                            
                        </tr>
                        <tr>
                            <td><label>Basic_Salary:</label></td>
                            <td><?php echo "$Basic_Salary";?></td>
                        </tr>
                       
                       
                        <tr>
                            <td><hr /></td>
                            <td><hr /></td>

                            <td><hr /></td>
                            <td><hr /></td>
                        </tr>
                        <tr>
                            <td><label>Gross_Salary:</label></td>
                            <td><?php echo "$Gross_Salary";?></td>

                            <td><label>Total Deductions:</label></td>
                            <td><?php echo "$Total_Ded";?></td>
							</tr>
                        </tr>
							<td><label>Net_Salary:</label></td>
                            <td><?php echo "$Net_Salary";?></td>
						</tr>
						
						
                    </table>
                </fieldset>
            </fieldset>
        </div>-->
		
    </form>
	<br />
			<?php
			echo fetch_customer_data($conn);
			?>	
</body>

</html>

