<!DOCTYPE html>
<html>

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Payroll System</title>

	<link rel="stylesheet" href="assets/demo.css">
	<link rel="stylesheet" href="assets/header-basic-light.css">
	<link href='http://fonts.googleapis.com/css?family=Cookie' rel='stylesheet' type='text/css'>

</head>

<body>

<header class="header-basic-light">

	<div class="header-limiter">

		<h1><a href="#">Payroll<span>Management</span></a></h1>

		<nav>
		<a href="#" class="selected">HOME</a>
			<a href="employee-login.php" >EMPLOYEE</a>
			<a href="admin-login.php">ADMIN</a>
			<a href="manager-login.php">MANAGER</a>
			

		</nav>
	</div>

</header>

<!-- The content of your page would go here. -->

