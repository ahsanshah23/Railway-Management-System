<?php

$conn = mysqli_connect('localhost', 'root', '','mypayroll');

if($conn-> connect_error)
{
	echo "connection failed";
}

$maxID = $_GET['UserName'];

$sql = "select Emp_ID from employee_tl where Emp_ID = $maxID ";
		$result = mysqli_query($conn,$sql);
		$row = mysqli_fetch_row($result);
		$Emp_ID = $row[0];
		
		$sql1 = "select Emp_Name from employee_tl where Emp_ID = $maxID ";
		$result1 = mysqli_query($conn,$sql1);
		$row1 = mysqli_fetch_row($result1);
		$Emp_Name = $row1[0];
		
		$sql2 = "select Emp_Father_Name from employee_tl where Emp_ID = $maxID ";
		$result2 = mysqli_query($conn,$sql2);
		$row2 = mysqli_fetch_row($result2);
		$Emp_Father_Name = $row2[0];
		
		$sql3 = "select Emp_DOB from employee_tl where Emp_ID = $maxID ";
		$result3 = mysqli_query($conn,$sql3);
		$row3 = mysqli_fetch_row($result3);
		$Emp_DOB = $row3[0];
		
		$sql4 = "select Emp_Age from employee_tl where Emp_ID = $maxID ";
		$result4 = mysqli_query($conn,$sql4);
		$row4 = mysqli_fetch_row($result4);
		$Emp_Age = $row4[0];
		
		$sql5 = "select Dept_ID from employee_tl where Emp_ID = $maxID ";
		$result5 = mysqli_query($conn,$sql5);
		$row5 = mysqli_fetch_row($result5);
		$Dept_ID = $row5[0];
		
		$sql6 = "select Designation_ID from employee_tl where Emp_ID = $maxID ";
		$result6 = mysqli_query($conn,$sql6);
		$row6 = mysqli_fetch_row($result6);
		$Designation_ID = $row6[0];
		
		$sql7 = "select Emp_Date from employee_tl where Emp_ID = $maxID ";
		$result7 = mysqli_query($conn,$sql7);
		$row7 = mysqli_fetch_row($result7);
		$Emp_Date = $row7[0];
		
		$sql8 = "select Emp_CNIC from employee_tl where Emp_ID = $maxID ";
		$result8 = mysqli_query($conn,$sql8);
		$row8 = mysqli_fetch_row($result8);
		$Emp_CNIC = $row8[0];
		
		$sql9 = "select Email from employee_tl where Emp_ID = $maxID ";
		$result9 = mysqli_query($conn,$sql9);
		$row9 = mysqli_fetch_row($result9);
		$Email = $row9[0];
		
		$sql10 = "select AccountNumber from employee_tl where Emp_ID = $maxID ";
		$result10 = mysqli_query($conn,$sql10);
		$row10 = mysqli_fetch_row($result10);
		$AccountNumber = $row10[0];
		
		$Designation_Name0 = "select Designation_Name from designation_tl where Designation_ID ='$Designation_ID'";
		$Designation_Name1 = mysqli_query($conn,$Designation_Name0);
		$Designation_Name2 = mysqli_fetch_row($Designation_Name1);
		$Designation_Name = $Designation_Name2[0];
		
		$Department_Name0 = "select Dept_Name from department_tl where Dept_ID ='$Dept_ID'";
		$Department_Name1 = mysqli_query($conn,$Department_Name0);
		$Department_Name2 = mysqli_fetch_row($Department_Name1);
		$Department_Name = $Department_Name2[0];	
?>




<html>
<head><style>
body {background-color: #F8F8F9;}

#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

.button {
    background-color: #998AD4;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
	border-radius: 4px;
    cursor: pointer;
	;
}
#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #998AD4;
    color: white;
}
#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}
#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}
</style>
    <title></title>
</head>
<body>
<?php //$ID='';
				$ID = $_GET['UserName']; ?>
    <form>
        <div>
		<input onclick="window.location.href = 'manager.php?UserName=<?php echo "$ID" ?>'" class="button" type="button" style="float: right;" value="Back" />
            <h2>PROFILE</h2>
           </br>
		   <fieldset>
			
                <legend></legend>
                <fieldset>
                    <legend></legend>
                    <table id="customers">
                        <tr align="center">
							<th colspan="4">OFFICE INFORMATION</th>
						</tr>	
						<tr>
							<td><label>Manager ID:</label></td>
							<td><?php echo "$maxID";?></td>
							
							<td><label>Department Name:</label></td>
							<td><?php echo "$Department_Name";?></td>
                        </tr>
						<tr>
							<td><label>Start Date:</label></td>
							<td><?php echo "$Emp_Date";?></td>
							<td><label>Designation Name:</label></td>
							<td><?php echo "$Designation_Name";?></td>
                        </tr>
                    </table>
                </fieldset>
				</br> </br> </br>
                <fieldset>
                    <legend></legend>
                    <table id="customers">
                        <tr align="center">
							<th colspan="4">PERSONAL INFORMATION</th>
						</tr>	
						<tr>
							<td><label>Name:</label></td>
							<td><?php echo "$Emp_Name";?></td>
							<td><label>Father Name:</label></td>
							<td><?php echo "$Emp_Father_Name";?></td>
                        </tr>
						<tr>
							<td><label>DOB:</label></td>
							<td><?php echo "$Emp_DOB";?></td>
							<td><label>Age:</label></td>
							<td><?php echo "$Emp_Age";?></td>
                        </tr>
						<tr>
							<td><label>CNIC :</label></td>
							<td><?php echo "$Emp_CNIC";?></td>
							<td><label>Email :</label></td>
							<td><?php echo "$Email";?></td>
                        </tr>
						<tr>
							<td><label>Acc No :</label></td>
							<td><?php echo "$AccountNumber";?></td>
                        </tr>
                    </table>
                </fieldset>
            </fieldset>
        </div>
    </form>
</body>
</html>