<html>
<head> 
	<style>
		body 
		{
			background-color: #F8F8F9;
			font-size: 20px;
			font-family:Helvetica,Sans-serif;
		}
		
		.button 
		{
		background-color: #998AD4;
		border: none;
		color: white;
		padding: 15px 32px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 16px;
		border-radius: 4px;
		margin: 4px 2px;
		cursor: pointer;
		;
		}

	</style>
</head>
<body >
	<form>
        <div> 
            <fieldset>
				<input onclick="window.location.href = 'admin.html'" class="button" type="button" style="float: right;" value="Back" />
                <legend></legend>
                <h2>Message Panel </h2>
                <hr />
				<?php
  
					$file_handle = fopen("forum.txt", "rb");

					while (!feof($file_handle) ) 
					{
						$line_of_text = fgets($file_handle);
						$parts = explode('=', $line_of_text);
						print $parts[0] . " ". "<BR>";
					}

					fclose($file_handle);
				?>
			</fieldset>
		</div>
	</form>
</body>
</html>

